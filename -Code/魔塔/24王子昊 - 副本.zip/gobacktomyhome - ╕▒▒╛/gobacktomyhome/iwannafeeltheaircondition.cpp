#include<iostream>
#include<conio.h>
#include<Windows.h>
#include <time.h>
#include <string>
#include "funcs.h"
using namespace std;
int imdead = 0;//�ж����������ٿ�ѭ��
int play = 0;//��
Item null = { "��    ", 0, 0, 0, EQUIP };//������Ϊ��
//���ű��
void Thread1()
{
	//char a = 57;
	//char* times = "60";
	//string time = times;
	//while (1)
	//{
	//	system(("title " + time).c_str());
	//	times[1] --;
	//	if (times[1] == a)
	//	{
	//		times[0] --;
	//	}
	//}
}
//������
int main()
{	
	system("title ħ��v1.2");
	int check = 1;
	while(1)
	{
		HANDLE hThread;
		DWORD ThreadID;
		system("mode con: cols=130 lines=40");//cmd��С
		srand(time(NULL));
		imdead = 0;
		int ***map = new int **[6];
		for (int x = 0; x < 6; x++)
		{
			map[x] = new int*[15];
			for (int y = 0; y < 15; y++)
			{
				map[x][y] = new int[15];
			}
		}
		Bag herosbag; //��
		Item items[5] = { null, null, null, null, null };//�ǿյ�
		Keys keys;//����Կ��
		for (int x = 0; x < 5; x++)
		{
			herosbag.item[x] = items[x];//�����ǵİ�
		}
		Hero hero;
		if (check == 1)
		{
			doge();
			head();//����
		}
		mainUI(map,hero,keys);//���˵�
		if (play == 1)//���ù�
		{
			hThread = CreateThread(NULL, 5, (LPTHREAD_START_ROUTINE)Thread1,NULL, 0, &ThreadID);
		}
		while (1)//û�Ҿͼ���
		{
			drawmap(map, hero, keys);//��
			gotmove(map, hero, keys);//��
			if (imdead == 1)
			{
				for (int x = 0; x < 6; x++)
				{
					for (int y = 0; y < 15; y++)
					{
						delete[]map[x][y];
					}
					delete[]map[x];
				}
				delete map;
				check = 0;
				break;
			}
		}
	}
	return 0;
}