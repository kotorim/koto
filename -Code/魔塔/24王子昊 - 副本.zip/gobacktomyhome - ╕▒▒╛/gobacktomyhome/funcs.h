enum Itemtype
{
	USE,
	EQUIP
};
struct Keys
{
	int red = 0;
	int blue = 0;
	int yellow = 0;
};
struct Item
{
	char name[20];
	int hpup;
	int atkup;
	int defup;
	Itemtype itemtype;
};

struct Bag
{
	int num = 0;
	Item item[5];
};
struct Hero
{
	int posx;
	int posy;
	char name[11];
	int lv;
	int hp;
	int exp;
	int atk;
	int def;
	int money;
	Bag bag;
};
struct Monster
{
	char name[20];
	int hp;
	int expup;
	int atk;
	int def;
	int moneyup;
};
void head();
void mainUI(int ***map, Hero &hero, Keys &keys);
void youdied();
void drawmap(int ***map, Hero hero, Keys keys);
void gamestart();
void gotmove(int ***map, Hero &hero,Keys &keys);
void elfspeak(int num,int ***map, Hero &hero);
bool fight(Hero &a, Monster b);
void market(Hero &hero, int ***map);
void doge();
extern int imdead;//����
extern int uplevel;
extern int play;
extern Item null;